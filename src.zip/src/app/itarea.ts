export interface Itarea {
    id: string;
    fecha: Date;
    hora: string;
    titulo: string;
    detalle: string;
    estado: string;
  }
